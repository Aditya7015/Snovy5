import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";

const API_URL = "http://localhost:5000";

export default function AccountOrders() {
  const [orders, setOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const token = localStorage.getItem("token");

  const fetchOrders = async () => {
    try {
      const res = await fetch(`${API_URL}/orders`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      setOrders(data);
    } catch (err) {
      console.error("Failed to load orders", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchOrders();
  }, []);

  if (loading)
    return (
      <div className="flex flex-col min-h-screen relative">
        <Header />
        <div className="container-custom py-20 flex-grow text-center text-gray-700 dark:text-gray-200 relative z-10">
          Loading your orders...
        </div>
        <Footer />
      </div>
    );

  if (orders.length === 0)
    return (
      <div className="flex flex-col min-h-screen relative">
        <Header />
        <div className="container-custom py-20 flex-grow text-center relative z-10">
          <h2 className="text-3xl font-semibold mb-3 text-gray-900 dark:text-gray-100">
            No Orders Yet
          </h2>
          <p className="text-gray-600 dark:text-gray-400 mb-8 text-lg">
            Looks like you haven’t ordered anything yet.
          </p>
          <Button className="px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-md shadow-md transition">
            <Link to="/shop">Shop Now</Link>
          </Button>
        </div>
        <Footer />
      </div>
    );

  return (
    <div className="flex flex-col min-h-screen relative">
      <Header />

      <main className="container-custom flex-grow py-12 relative z-10">
        <h1 className="text-4xl font-serif font-semibold mb-10 text-gray-900 dark:text-gray-100 text-center md:text-left">
          My Orders
        </h1>

        <div className="space-y-8">
          {orders.map((order) => (
            <div
              key={order.id}
              className="bg-white/90 dark:bg-gray-800/90 backdrop-blur-md shadow-lg rounded-xl p-6 transition hover:shadow-2xl"
            >
              {/* Order Header */}
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
                <div className="mb-4 md:mb-0">
                  <p className="text-lg md:text-xl font-semibold text-gray-900 dark:text-gray-100">
                    Order #{order.id}
                  </p>
                  <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                    {new Date(order.date).toLocaleDateString()}
                  </p>
                  <p className="text-sm mt-2">
                    <span className="font-medium">Status:</span>{" "}
                    <span
                      className={`capitalize px-3 py-1 rounded-full text-xs font-semibold ${
                        order.status === "delivered"
                          ? "bg-green-100 text-green-800 dark:bg-green-800 dark:text-green-100"
                          : order.status === "pending"
                          ? "bg-yellow-100 text-yellow-800 dark:bg-yellow-800 dark:text-yellow-100"
                          : "bg-blue-100 text-blue-800 dark:bg-blue-800 dark:text-blue-100"
                      }`}
                    >
                      {order.status}
                    </span>
                  </p>
                </div>

                {/* View Details Button */}
                <Button
                  asChild
                  className="mt-4 md:mt-0 px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg shadow-md transition font-medium text-sm md:text-base"
                >
                  <Link to={`/order-confirmation/${order.id}`}>View Details</Link>
                </Button>
              </div>

              {/* Items Preview */}
              <div className="flex gap-3 overflow-x-auto scrollbar-hide mt-4">
                {order.items.slice(0, 4).map((item: any, idx: number) => (
                  <div
                    key={idx}
                    className="flex-shrink-0 w-20 sm:w-24 p-2 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-md flex flex-col items-center hover:shadow-sm transition"
                  >
                    <img
                      src={item.image}
                      alt={item.name}
                      className="w-16 h-16 sm:w-20 sm:h-20 object-cover rounded-md"
                    />
                    <p className="text-center text-gray-800 dark:text-gray-100 text-xs sm:text-sm mt-1 truncate">
                      {item.name}
                    </p>
                    <p className="text-gray-500 dark:text-gray-300 text-xs mt-0.5">
                      {item.quantity} × ₹{item.price}
                    </p>
                  </div>
                ))}

                {order.items.length > 4 && (
                  <div className="flex-shrink-0 w-20 sm:w-24 p-2 flex items-center justify-center bg-gray-200 dark:bg-gray-600 rounded-md text-xs sm:text-sm font-semibold text-gray-800 dark:text-gray-100">
                    +{order.items.length - 4} more
                  </div>
                )}
              </div>

              {/* Total */}
              <div className="text-right mt-6 text-lg md:text-xl font-semibold text-gray-900 dark:text-gray-100">
                Total: ₹{order.total}
              </div>
            </div>
          ))}
        </div>
      </main>

      <Footer />
    </div>
  );
}
